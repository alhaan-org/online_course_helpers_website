<footer class="pt-5 text-white" style="background-color: #002a4d;">
  <div class="container">
    <div class="row g-4 mb-5">
      <div class="col-lg-3">
        <a href="https://onlinecoursehelpers.com">
          <img src="assets/img/online-course-helpers-logo.png" alt="Online Course Helpers" class="footer-logo mb-3" loading="lazy">
        </a>
        <p class="small opacity-75">Online Course Helpers offers a one-stop solution to students seeking
          additional credits. Hire professional helpers with full confidentiality.</p>
      </div>
      <div class="col-lg-3">
        <h5 class="text-warning fw-bold mb-4">Our Services</h5>
        <ul class="list-unstyled small opacity-75 lh-lg">
          <li class="footer-link"><a href="aleks-course-help">Aleks Course Help</a></li>
          <li class="footer-link"><a href="pearson-course-help">Pearson Course Help</a></li>
          <li class="footer-link"><a href="mcgrawhill-course-help">McGraw Hill Course Help</a></li>
          <li class="footer-link"><a href="blackboard-course-help">Blackboard Course Help</a></li>
          <li class="footer-link"><a href="brightspace-course-help">Brightspace Course Help</a></li>
          <li class="footer-link"><a href="sophia-course-help">Sophia Course Help</a></li>
          <li class="footer-link"><a href="wgu-course-help">WGU Course Help</a></li>
          <li class="footer-link"><a href="straighter-line-course-help">Straighterline Course Help</a></li>
          <li class="footer-link"><a href="cengage-course-help">Cengage Course Help</a></li>
          <li class="footer-link"><a href="act-course-help">ACT Course Help</a></li>
          <li class="footer-link"><a href="moodle-course-help">Moodle Course Help</a></li>
          <li class="footer-link"><a href="canvas-course-help">CANVAS Course Help</a></li>
          <li class="footer-link"><a href="mathway-course-help">Mathway Course Help</a></li>
        </ul>
      </div>
      <div class="col-lg-2">
        <h5 class="text-warning fw-bold mb-4">Information</h5>
        <ul class="list-unstyled small opacity-75 lh-lg">
          <li class="footer-link"><a href="https://onlinecoursehelpers.com">Home</a></li>
          <li class="footer-link"><a href="#">Blog</a></li>
          <li class="footer-link"><a href="https://onlinecoursehelpers.com/terms-conditions/">Terms and
              Conditions</a></li>
          <li class="footer-link"><a href="https://onlinecoursehelpers.com/refund-policy/">Refund Policy</a>
          </li>
          <li class="footer-link"><a href="https://onlinecoursehelpers.com/privacy-policy/">Privacy Policy</a>
          </li>
        </ul>
      </div>
      <div class="col-lg-4 footer-contact">
        <h5 class="text-warning fw-bold mb-4">Contact us</h5>
        <a href="mailto:info@onlinecoursehelpers.com" class="small"><i class="fa fa-envelope text-warning me-2"></i> info@onlinecoursehelpers.com</a>
        <a href="tel:+12184192935" class="small"><i class="fa fa-phone text-warning me-2"></i> (+1) 218 419 2935</a>
        <p class="small mb-2"><i class="fa fa-location text-warning me-2"></i> 110 Central Ave, Jersey City, NJ
          07307</p>
        <h5 class="text-warning fw-bold mt-4">Follow us</h5>
        <div class="d-flex gap-3 fs-5">
          <a href="https://www.facebook.com/onlinecoursehelperss/"><i
              class="fab fa-facebook footer-social-icon"></i></a>
          <a href="https://www.instagram.com/onlinecoursehelpers/"><i
              class="fab fa-instagram footer-social-icon"></i></a>
          <a href="https://www.pinterest.com/socialmedia0003/"><i class="fab fa-pinterest footer-social-icon"></i></a>
          <a href="https://x.com/onlinecourse54"><i class="fab fa-x-twitter footer-social-icon"></i></a>
          <a href="https://www.linkedin.com/company/online-course-helpers/"><i
              class="fab fa-linkedin footer-social-icon"></i></a>
        </div>
        <div class="img-fluid">
          <img src="assets/img/gaurantee-img.png" alt="Trust Seal" class="mt-4" style="width: 200px; height: auto;">
        </div>
      </div>
    </div>
  </div>
  <div style="background-color: #00334d;" class="py-3">
    <div class="text-center small opacity-50">Copyright &copy; Online Course Helpers 2025. All rights reserved.
    </div>
  </div>
</footer>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
  var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
  (function () {
    var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
    s1.async = true;
    s1.src = 'https://embed.tawk.to/6980c18ec519551c3514da51/1jgff85ht';
    s1.charset = 'UTF-8';
    s1.setAttribute('crossorigin', '*');
    s0.parentNode.insertBefore(s1, s0);
  })();
</script>
<!--End of Tawk.to Script-->

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 1200,
    once: true,
  });
</script>